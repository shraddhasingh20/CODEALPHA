"""LSTM language model over note tokens."""

import torch.nn as nn


class MusicLSTM(nn.Module):
    """Embedding -> stacked LSTM -> linear layer predicting the next token at every step."""

    def __init__(self, vocab_size, embed_dim=128, hidden_size=256, num_layers=2, dropout=0.3):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, embed_dim)
        self.lstm = nn.LSTM(embed_dim, hidden_size, num_layers, batch_first=True,
                            dropout=dropout if num_layers > 1 else 0.0)
        self.drop = nn.Dropout(dropout)
        self.fc = nn.Linear(hidden_size, vocab_size)

    def forward(self, x, hidden=None):
        """x: (batch, seq) token ids -> logits (batch, seq, vocab), plus the LSTM state."""
        out, hidden = self.lstm(self.drop(self.embed(x)), hidden)
        return self.fc(self.drop(out)), hidden
