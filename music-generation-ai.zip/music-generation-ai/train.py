"""
Step 2: train the LSTM to predict the next note token.

Example:
    python train.py --epochs 30
    python train.py --epochs 60 --hidden-size 512 --seq-len 64 --device cuda
"""

import argparse
import csv
import json
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset

from model import MusicLSTM


def parse_args():
    p = argparse.ArgumentParser(description="Train the music LSTM")
    p.add_argument("--data-dir", default="data/processed")
    p.add_argument("--out", default="models/music_lstm.pt")
    p.add_argument("--seq-len", type=int, default=32, help="context window length in tokens")
    p.add_argument("--stride", type=int, default=1, help="step between training windows")
    p.add_argument("--epochs", type=int, default=30)
    p.add_argument("--batch-size", type=int, default=128)
    p.add_argument("--lr", type=float, default=2e-3)
    p.add_argument("--embed-dim", type=int, default=128)
    p.add_argument("--hidden-size", type=int, default=256)
    p.add_argument("--layers", type=int, default=2)
    p.add_argument("--dropout", type=float, default=0.3)
    p.add_argument("--val-fraction", type=float, default=0.1)
    p.add_argument("--device", default=None, help="cpu, cuda, mps (default: auto)")
    p.add_argument("--seed", type=int, default=42)
    return p.parse_args()


class WindowDataset(Dataset):
    """Sliding windows: input = tokens[s : s+L], target = tokens[s+1 : s+L+1]."""

    def __init__(self, tokens, starts, seq_len):
        self.tokens, self.starts, self.seq_len = tokens, starts, seq_len

    def __len__(self):
        return len(self.starts)

    def __getitem__(self, i):
        s = self.starts[i]
        return self.tokens[s:s + self.seq_len], self.tokens[s + 1:s + self.seq_len + 1]


def make_splits(lengths, seq_len, stride, val_fraction):
    """Split each piece at ~(1 - val_fraction) so train and validation windows never overlap."""
    train, val, offset = [], [], 0
    for length in lengths:
        cut = int((1.0 - val_fraction) * length)
        train += [offset + s for s in range(0, cut - seq_len, stride)]
        val += [offset + s for s in range(cut, length - seq_len, stride)]
        offset += int(length)
    return train, val


def run_epoch(model, loader, loss_fn, device, optimizer=None):
    training = optimizer is not None
    model.train(training)
    total, count = 0.0, 0
    with torch.set_grad_enabled(training):
        for x, y in loader:
            x, y = x.to(device), y.to(device)
            logits, _ = model(x)
            loss = loss_fn(logits.reshape(-1, logits.size(-1)), y.reshape(-1))
            if training:
                optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                optimizer.step()
            total += loss.item() * x.size(0)
            count += x.size(0)
    return total / max(count, 1)


def main():
    args = parse_args()
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    device = args.device or ("cuda" if torch.cuda.is_available()
                             else "mps" if torch.backends.mps.is_available() else "cpu")

    data = Path(args.data_dir)
    tokens = torch.from_numpy(np.load(data / "tokens.npy"))
    lengths = np.load(data / "lengths.npy")
    with open(data / "vocab.json") as f:
        vocab = json.load(f)

    train_starts, val_starts = make_splits(lengths, args.seq_len, args.stride, args.val_fraction)
    if not train_starts:
        raise SystemExit("Not enough data for this --seq-len. Lower it or add more MIDI files.")
    train_loader = DataLoader(WindowDataset(tokens, train_starts, args.seq_len),
                              batch_size=args.batch_size, shuffle=True)
    val_loader = (DataLoader(WindowDataset(tokens, val_starts, args.seq_len), batch_size=args.batch_size)
                  if val_starts else None)

    print(f"Device: {device} | vocab: {len(vocab)} | train windows: {len(train_starts)} "
          f"| val windows: {len(val_starts)}")

    model = MusicLSTM(len(vocab), args.embed_dim, args.hidden_size, args.layers, args.dropout).to(device)
    loss_fn = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, factor=0.5, patience=2)

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    # A pool of real windows lets generate.py start from a realistic seed without the dataset.
    pool = np.random.choice(train_starts, size=min(256, len(train_starts)), replace=False)
    seed_windows = torch.stack([tokens[s:s + args.seq_len] for s in pool])

    best_val, history = float("inf"), []
    for epoch in range(1, args.epochs + 1):
        t0 = time.time()
        train_loss = run_epoch(model, train_loader, loss_fn, device, optimizer)
        val_loss = run_epoch(model, val_loader, loss_fn, device) if val_loader else train_loss
        scheduler.step(val_loss)
        history.append((epoch, train_loss, val_loss))
        print(f"Epoch {epoch:3d}/{args.epochs} | train {train_loss:.4f} | val {val_loss:.4f} "
              f"| {time.time() - t0:.1f}s")

        if val_loss < best_val:
            best_val = val_loss
            torch.save({
                "model_state": model.state_dict(),
                "vocab": vocab,
                "seed_windows": seed_windows,
                "config": {"embed_dim": args.embed_dim, "hidden_size": args.hidden_size,
                           "layers": args.layers, "dropout": args.dropout, "seq_len": args.seq_len},
            }, out_path)

    with open(out_path.with_suffix(".loss.csv"), "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["epoch", "train_loss", "val_loss"])
        writer.writerows(history)
    print(f"\nBest val loss {best_val:.4f}. Model saved to {out_path}")


if __name__ == "__main__":
    main()
