# Music Generation with AI (LSTM + music21)

Trains an LSTM on MIDI music (classical, jazz, or anything you provide), then generates new pieces and saves them as **MIDI** and **WAV audio**.

```
MIDI files ──► music21 preprocessing ──► note/chord tokens ──► LSTM training ──► sampling ──► .mid + .wav
```

## Features

- Works with your own MIDI collection or music21's built-in classical corpus (Bach, Mozart, Beethoven, ...)
- Tokens capture pitch, chords **and** duration (e.g. `60.64.67|1` = C-major chord for one beat) plus rests
- Optional transposition to C major / A minor so the model learns musical patterns, not 24 keys
- PyTorch LSTM with validation split, LR scheduling, and best-model checkpointing
- Temperature and top-k sampling to control how safe or adventurous the output is
- Audio export with a built-in NumPy synthesiser (no extra tools needed), or FluidSynth + SoundFont for realistic sound

## Project Structure

```
.
├── preprocess.py        # MIDI -> token sequences (music21)
├── model.py             # LSTM model
├── train.py             # training loop
├── generate.py          # sampling, MIDI + WAV export
├── utils.py             # token format, sampling, WAV synthesiser
├── tests/test_utils.py  # quick checks for utils.py
├── data/midi/           # put your own .mid files here
├── models/              # trained checkpoints (created by train.py)
├── outputs/             # generated music (created by generate.py)
├── requirements.txt
└── LICENSE
```

## Installation

Requires Python 3.9+.

```bash
git clone https://github.com/<your-username>/<your-repo>.git
cd <your-repo>

python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate

pip install -r requirements.txt
```

Optional, for higher-quality audio: install [FluidSynth](https://www.fluidsynth.org/) and download any General MIDI `.sf2` SoundFont.

## 1. Collect data

**Option A: built-in classical corpus (no download).**
music21 ships with thousands of public-domain scores, so this works out of the box:

```bash
python preprocess.py --source corpus --composers bach mozart --max-files 100
```

**Option B: your own MIDI (classical, jazz, etc.).**
Copy `.mid` / `.midi` files into `data/midi/` (sub-folders are fine), then:

```bash
python preprocess.py --source midi --midi-dir data/midi
```

Public MIDI collections you can use include the MAESTRO dataset (piano performances), the Lakh MIDI dataset, and many jazz/classical MIDI archives. Check each dataset's license before redistributing anything. For a cleaner style, train on one genre or composer at a time.

Preprocessing writes `tokens.npy`, `lengths.npy` and `vocab.json` to `data/processed/`.

## 2. Train

```bash
python train.py --epochs 30
# bigger model on a GPU:
python train.py --epochs 60 --hidden-size 512 --seq-len 64 --device cuda
```

The best checkpoint (lowest validation loss) is saved to `models/music_lstm.pt`, and the loss curve to `models/music_lstm.loss.csv`.

## 3. Generate, save and play

```bash
python generate.py                                   # 200 tokens -> outputs/generated.mid + .wav
python generate.py --length 400 --temperature 0.9 --bpm 90 --num 3
python generate.py --soundfont path/to/font.sf2      # realistic instrument audio
```

Play `outputs/generated.wav` in any audio player. Open the `.mid` in VLC, MuseScore, GarageBand, or a DAW to hear it with real instruments or edit the notes.

### Options

| Script | Option | Default | Description |
|---|---|---|---|
| preprocess | `--source` | `corpus` | `midi` (your files) or `corpus` (music21) |
| preprocess | `--composers` | `bach` | Corpus composers |
| preprocess | `--max-files` | `100` | Cap on pieces parsed |
| preprocess | `--max-chord-size` | `4` | Max notes kept per chord |
| preprocess | `--min-count` | `2` | Drop tokens rarer than this |
| train | `--seq-len` | `32` | Context window (tokens) |
| train | `--epochs` | `30` | Training epochs |
| train | `--hidden-size` | `256` | LSTM units |
| train | `--layers` | `2` | LSTM layers |
| train | `--lr` | `2e-3` | Learning rate |
| generate | `--length` | `200` | Tokens to generate |
| generate | `--temperature` | `1.0` | Lower = safer, higher = more random |
| generate | `--top-k` | `0` | Restrict to k likeliest tokens |
| generate | `--bpm` | `100` | Tempo |
| generate | `--seed` | none | Reproducible output |

## Tuning Tips

- **Output wanders or sounds random:** lower `--temperature` (0.7-0.9), use `--top-k 10`, or train longer on more data.
- **Output is repetitive or loops:** raise `--temperature` slightly, or add more varied training data.
- **Training loss drops but validation loss rises:** the model is memorising. Add data, raise `--dropout`, or reduce `--hidden-size`.
- **Large vocabulary / slow training:** lower `--max-chord-size` or raise `--min-count`.

## Limitations

- Token streams are a single merged timeline (voices are combined with `chordify`), so the model does not learn separate melody and accompaniment lines.
- Rhythm is quantised to a fixed set of durations, so subtle timing and dynamics are lost.
- An LSTM captures local patterns well but not long-range structure such as repeated sections. A Transformer or a GAN can be swapped in behind the same token format.

## Tests

```bash
python tests/test_utils.py
```

## Pushing to GitHub

```bash
git init
git add .
git commit -m "Add LSTM music generation pipeline"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

## Acknowledgements

- [music21](https://web.mit.edu/music21/) for MIDI parsing and writing
- [PyTorch](https://pytorch.org/)

## License

MIT, see [LICENSE](LICENSE).
