"""
Step 3: generate new music with the trained model, save it as MIDI and WAV audio.

Examples:
    python generate.py
    python generate.py --length 400 --temperature 0.9 --bpm 90 --num 3
    python generate.py --soundfont /path/to/font.sf2      # nicer audio via FluidSynth (optional)
"""

import argparse
import shutil
import subprocess
from pathlib import Path

import numpy as np
import torch
from music21 import chord, instrument, note, stream, tempo

from model import MusicLSTM
from utils import parse_token, render_wav, sample_index, tokens_to_events


def parse_args():
    p = argparse.ArgumentParser(description="Generate music from a trained model")
    p.add_argument("--model", default="models/music_lstm.pt")
    p.add_argument("--length", type=int, default=200, help="number of note/chord tokens to generate")
    p.add_argument("--temperature", type=float, default=1.0, help="<1 safer, >1 more random")
    p.add_argument("--top-k", type=int, default=0, help="sample only from the k likeliest tokens (0 = off)")
    p.add_argument("--bpm", type=int, default=100)
    p.add_argument("--num", type=int, default=1, help="how many pieces to generate")
    p.add_argument("--out-dir", default="outputs")
    p.add_argument("--name", default="generated")
    p.add_argument("--soundfont", default=None, help=".sf2 file; renders audio with FluidSynth if installed")
    p.add_argument("--seed", type=int, default=None, help="random seed for reproducible output")
    p.add_argument("--device", default="cpu")
    return p.parse_args()


def load_model(path, device):
    ckpt = torch.load(path, map_location=device, weights_only=True)
    cfg = ckpt["config"]
    model = MusicLSTM(len(ckpt["vocab"]), cfg["embed_dim"], cfg["hidden_size"],
                      cfg["layers"], cfg["dropout"]).to(device)
    model.load_state_dict(ckpt["model_state"])
    model.eval()
    return model, ckpt["vocab"], ckpt["seed_windows"]


@torch.no_grad()
def generate_tokens(model, vocab, seed_windows, length, temperature, top_k, rng, device):
    seed = seed_windows[rng.integers(len(seed_windows))].unsqueeze(0).to(device)
    logits, hidden = model(seed)
    last = logits[0, -1].cpu().numpy()

    out = []
    for _ in range(length):
        idx = sample_index(last, temperature, top_k, rng)
        out.append(vocab[idx])
        logits, hidden = model(torch.tensor([[idx]], device=device), hidden)
        last = logits[0, -1].cpu().numpy()
    return out


def tokens_to_midi(tokens, path, bpm):
    s = stream.Stream()
    s.append(tempo.MetronomeMark(number=bpm))
    s.append(instrument.Piano())
    for token in tokens:
        pitches, dur = parse_token(token)
        if not pitches:
            el = note.Rest()
        elif len(pitches) == 1:
            el = note.Note(pitches[0])
        else:
            el = chord.Chord(pitches)
        el.quarterLength = dur
        s.append(el)
    s.write("midi", fp=str(path))


def midi_to_wav_fluidsynth(midi_path, wav_path, soundfont):
    subprocess.run(["fluidsynth", "-ni", soundfont, str(midi_path), "-F", str(wav_path), "-r", "44100"],
                   check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def main():
    args = parse_args()
    rng = np.random.default_rng(args.seed)
    model, vocab, seed_windows = load_model(args.model, args.device)

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    for i in range(1, args.num + 1):
        tokens = generate_tokens(model, vocab, seed_windows, args.length,
                                 args.temperature, args.top_k, rng, args.device)
        stem = f"{args.name}_{i}" if args.num > 1 else args.name
        midi_path, wav_path = out_dir / f"{stem}.mid", out_dir / f"{stem}.wav"

        tokens_to_midi(tokens, midi_path, args.bpm)

        if args.soundfont and shutil.which("fluidsynth"):
            midi_to_wav_fluidsynth(midi_path, wav_path, args.soundfont)
        else:
            if args.soundfont:
                print("fluidsynth not found; using the built-in synthesiser instead.")
            render_wav(tokens_to_events(tokens, args.bpm), wav_path)

        print(f"Saved {midi_path} and {wav_path}")


if __name__ == "__main__":
    main()
