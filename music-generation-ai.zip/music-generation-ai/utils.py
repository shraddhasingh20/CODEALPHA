"""
Shared helpers: note-token format, sampling, and a dependency-free WAV synthesiser.

Token format
------------
Every musical event is one string token: "<pitches>|<duration>"
    "60|0.5"        a C4 note lasting half a quarter-note
    "60.64.67|1"    a C-major chord lasting one quarter-note
    "R|0.25"        a rest lasting a sixteenth note
Pitches are MIDI numbers (60 = middle C); durations are in quarter-note lengths.
"""

import wave

import numpy as np

# Durations (in quarter-note lengths) that real durations are snapped to.
DURATIONS = [0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0]


def quantize_duration(quarter_length):
    """Snap a duration to the nearest value in DURATIONS (keeps the vocabulary small)."""
    ql = float(quarter_length)
    return min(DURATIONS, key=lambda d: abs(d - ql))


def make_token(pitches, duration):
    """Build a token string from a list of MIDI pitches (empty list = rest) and a duration."""
    pitch_part = "R" if not pitches else ".".join(str(int(p)) for p in sorted(set(pitches)))
    return f"{pitch_part}|{duration:g}"


def parse_token(token):
    """Inverse of make_token. Returns (list_of_midi_pitches, duration)."""
    pitch_part, dur_part = token.split("|")
    pitches = [] if pitch_part == "R" else [int(p) for p in pitch_part.split(".")]
    return pitches, float(dur_part)


def sample_index(logits, temperature=1.0, top_k=0, rng=None):
    """
    Sample a token index from raw logits.
    temperature < 1 -> safer / more repetitive, > 1 -> more adventurous.
    top_k > 0 restricts sampling to the k most likely tokens.
    """
    rng = rng or np.random.default_rng()
    logits = np.asarray(logits, dtype=np.float64)
    if temperature <= 0:
        return int(np.argmax(logits))
    logits = logits / temperature
    if top_k and top_k < len(logits):
        cutoff = np.partition(logits, -top_k)[-top_k]
        logits = np.where(logits < cutoff, -np.inf, logits)
    logits = logits - logits.max()
    probs = np.exp(logits)
    probs /= probs.sum()
    return int(rng.choice(len(probs), p=probs))


def tokens_to_events(tokens, bpm=100):
    """Turn tokens into (pitches, start_seconds, duration_seconds) events, played one after another."""
    sec_per_beat = 60.0 / bpm
    t = 0.0
    events = []
    for token in tokens:
        pitches, beats = parse_token(token)
        dur = beats * sec_per_beat
        if pitches:
            events.append((pitches, t, dur))
        t += dur
    return events


def render_wav(events, path, sample_rate=22050):
    """
    Render events to a 16-bit mono WAV with a simple additive synth
    (a few harmonics + attack/decay/release envelope). Needs only NumPy.
    For nicer instrument sounds, render the MIDI with FluidSynth and a SoundFont instead.
    """
    if not events:
        raise ValueError("No notes to render.")

    release = 0.4
    total_seconds = max(start + dur for _, start, dur in events) + release + 0.5
    audio = np.zeros(int(total_seconds * sample_rate) + 1)
    harmonics = [(1, 1.0), (2, 0.45), (3, 0.25), (4, 0.12), (5, 0.06)]

    for pitches, start, dur in events:
        n = int((dur + release) * sample_rate)
        hold = int(dur * sample_rate)
        t = np.arange(n) / sample_rate

        env = np.full(n, 0.6)
        attack = max(1, min(int(0.01 * sample_rate), n))
        decay_end = min(attack + int(0.15 * sample_rate), n)
        env[:attack] = np.linspace(0.0, 1.0, attack)
        env[attack:decay_end] = np.linspace(1.0, 0.6, decay_end - attack)
        if n > hold:
            env[hold:] *= np.linspace(1.0, 0.0, n - hold) ** 2

        for midi_pitch in pitches:
            freq = 440.0 * 2.0 ** ((midi_pitch - 69) / 12.0)
            tone = np.zeros(n)
            for h, amp in harmonics:
                if freq * h < sample_rate / 2:
                    tone += amp * np.sin(2.0 * np.pi * freq * h * t)
            offset = int(start * sample_rate)
            audio[offset:offset + n] += tone * env / np.sqrt(len(pitches))

    peak = np.max(np.abs(audio))
    if peak > 0:
        audio = audio / peak * 0.9
    pcm = (audio * 32767).astype(np.int16)

    with wave.open(str(path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(pcm.tobytes())
