"""
Step 1: turn MIDI files into note-token sequences with music21.

Each piece is optionally transposed to C major / A minor (so the model learns patterns
instead of 24 separate keys), its voices are merged with chordify(), and every note, chord
or rest becomes a token like "60.64.67|1" (see utils.py).

Examples:
    python preprocess.py --source corpus --composers bach mozart --max-files 60
    python preprocess.py --source midi --midi-dir data/midi          # your own classical/jazz MIDI
"""

import argparse
import json
from collections import Counter
from pathlib import Path

import numpy as np
from music21 import chord, converter, corpus, interval, note, pitch

from utils import make_token, quantize_duration


def parse_args():
    p = argparse.ArgumentParser(description="MIDI -> token sequences")
    p.add_argument("--source", choices=["midi", "corpus"], default="corpus",
                   help="'midi' = your own files in --midi-dir, 'corpus' = music21's built-in corpus")
    p.add_argument("--midi-dir", default="data/midi", help="folder searched recursively for .mid/.midi")
    p.add_argument("--composers", nargs="+", default=["bach"],
                   help="music21 corpus composers (e.g. bach mozart beethoven)")
    p.add_argument("--max-files", type=int, default=100, help="cap on number of pieces (0 = no cap)")
    p.add_argument("--no-transpose", action="store_true", help="do not transpose to C major / A minor")
    p.add_argument("--max-chord-size", type=int, default=4, help="keep at most this many notes per chord")
    p.add_argument("--min-count", type=int, default=2, help="drop tokens seen fewer times than this")
    p.add_argument("--min-length", type=int, default=64, help="skip pieces shorter than this many tokens")
    p.add_argument("--out-dir", default="data/processed")
    return p.parse_args()


def collect_paths(args):
    if args.source == "midi":
        folder = Path(args.midi_dir)
        paths = sorted([*folder.rglob("*.mid"), *folder.rglob("*.midi"),
                        *folder.rglob("*.MID"), *folder.rglob("*.MIDI")])
        if not paths:
            raise SystemExit(f"No MIDI files found in {folder}/ - add some, or use --source corpus.")
    else:
        paths = []
        for composer in args.composers:
            found = list(corpus.getComposer(composer))
            if not found:
                print(f"Warning: no corpus pieces for composer '{composer}'")
            paths.extend(found)
    if args.max_files:
        paths = paths[:args.max_files]
    return paths


def piece_to_tokens(path, transpose=True, max_chord_size=4):
    """Parse one file into a list of tokens."""
    score = converter.parse(str(path))

    if transpose:
        try:
            k = score.analyze("key")
            target = pitch.Pitch("C") if k.mode == "major" else pitch.Pitch("A")
            score = score.transpose(interval.Interval(k.tonic, target))
        except Exception:
            pass  # keep original key if analysis fails

    tokens = []
    for el in score.chordify().flatten().notesAndRests:
        if el.duration.quarterLength <= 0:      # skip grace notes
            continue
        dur = quantize_duration(el.duration.quarterLength)
        if isinstance(el, note.Rest):
            tokens.append(make_token([], dur))
        elif isinstance(el, note.Note):
            tokens.append(make_token([el.pitch.midi], dur))
        elif isinstance(el, chord.Chord):
            pitches = sorted({p.midi for p in el.pitches})
            tokens.append(make_token(pitches[-max_chord_size:], dur))   # keep the highest notes
    return tokens


def main():
    args = parse_args()
    paths = collect_paths(args)
    print(f"Parsing {len(paths)} files ...")

    pieces = []
    for i, path in enumerate(paths, 1):
        try:
            tokens = piece_to_tokens(path, not args.no_transpose, args.max_chord_size)
        except Exception as e:
            print(f"  [{i}/{len(paths)}] skipped {Path(path).name}: {e}")
            continue
        if len(tokens) < args.min_length:
            print(f"  [{i}/{len(paths)}] skipped {Path(path).name}: too short ({len(tokens)} tokens)")
            continue
        pieces.append(tokens)
        print(f"  [{i}/{len(paths)}] {Path(path).name}: {len(tokens)} tokens")

    if not pieces:
        raise SystemExit("No usable pieces were parsed.")

    # Build vocabulary, dropping very rare tokens.
    counts = Counter(t for piece in pieces for t in piece)
    vocab = sorted(t for t, c in counts.items() if c >= args.min_count)
    token_to_id = {t: i for i, t in enumerate(vocab)}

    encoded, lengths = [], []
    for piece in pieces:
        ids = [token_to_id[t] for t in piece if t in token_to_id]
        if len(ids) >= args.min_length:
            encoded.append(np.array(ids, dtype=np.int64))
            lengths.append(len(ids))

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    np.save(out / "tokens.npy", np.concatenate(encoded))
    np.save(out / "lengths.npy", np.array(lengths, dtype=np.int64))
    with open(out / "vocab.json", "w") as f:
        json.dump(vocab, f)

    print(f"\nSaved {len(encoded)} pieces, {sum(lengths)} tokens, vocabulary of {len(vocab)} to {out}/")


if __name__ == "__main__":
    main()
