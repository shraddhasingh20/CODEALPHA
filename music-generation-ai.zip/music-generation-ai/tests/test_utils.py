"""Dependency-light checks for utils.py. Run with:  python tests/test_utils.py"""

import sys
import tempfile
import wave
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from utils import (make_token, parse_token, quantize_duration, render_wav,  # noqa: E402
                   sample_index, tokens_to_events)


def test_token_roundtrip():
    assert parse_token(make_token([64, 60, 67], 1.0)) == ([60, 64, 67], 1.0)
    assert parse_token(make_token([], 0.25)) == ([], 0.25)
    assert make_token([60], 0.5) == "60|0.5"


def test_quantize():
    assert quantize_duration(0.3) == 0.25
    assert quantize_duration(1.2) == 1.0
    assert quantize_duration(10) == 4.0


def test_sampling():
    logits = np.array([0.0, 5.0, 0.0])
    assert sample_index(logits, temperature=0) == 1
    rng = np.random.default_rng(0)
    assert all(sample_index(logits, 1.0, top_k=1, rng=rng) == 1 for _ in range(20))
    picks = {sample_index(np.zeros(4), 1.0, rng=rng) for _ in range(200)}
    assert picks == {0, 1, 2, 3}


def test_events_and_wav():
    tokens = ["60|1", "R|0.5", "60.64.67|2"]
    events = tokens_to_events(tokens, bpm=120)
    assert events[0] == ([60], 0.0, 0.5)
    assert events[1][1] == 0.75
    with tempfile.TemporaryDirectory() as d:
        path = Path(d) / "t.wav"
        render_wav(events, path)
        with wave.open(str(path)) as wf:
            assert wf.getframerate() == 22050 and wf.getnframes() > 22050


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("ok", name)
