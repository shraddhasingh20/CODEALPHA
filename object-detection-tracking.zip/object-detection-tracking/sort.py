"""
SORT: Simple Online and Realtime Tracking (Bewley et al., 2016).

Self-contained implementation using only NumPy and SciPy.
Each track is a constant-velocity Kalman filter over the bounding box
(centre x, centre y, area, aspect ratio). Detections are matched to
predicted tracks with the Hungarian algorithm on an IoU cost matrix.
"""

import numpy as np
from scipy.optimize import linear_sum_assignment


def iou_batch(boxes_a: np.ndarray, boxes_b: np.ndarray) -> np.ndarray:
    """Pairwise IoU between two sets of [x1, y1, x2, y2] boxes."""
    if len(boxes_a) == 0 or len(boxes_b) == 0:
        return np.zeros((len(boxes_a), len(boxes_b)))
    a = np.expand_dims(boxes_a, 1)
    b = np.expand_dims(boxes_b, 0)
    xx1 = np.maximum(a[..., 0], b[..., 0])
    yy1 = np.maximum(a[..., 1], b[..., 1])
    xx2 = np.minimum(a[..., 2], b[..., 2])
    yy2 = np.minimum(a[..., 3], b[..., 3])
    w = np.maximum(0.0, xx2 - xx1)
    h = np.maximum(0.0, yy2 - yy1)
    inter = w * h
    area_a = (a[..., 2] - a[..., 0]) * (a[..., 3] - a[..., 1])
    area_b = (b[..., 2] - b[..., 0]) * (b[..., 3] - b[..., 1])
    return inter / (area_a + area_b - inter + 1e-9)


def bbox_to_z(bbox):
    """[x1, y1, x2, y2] -> [cx, cy, area, aspect_ratio] column vector."""
    w = bbox[2] - bbox[0]
    h = bbox[3] - bbox[1]
    cx = bbox[0] + w / 2.0
    cy = bbox[1] + h / 2.0
    return np.array([cx, cy, w * h, w / float(h + 1e-9)]).reshape((4, 1))


def x_to_bbox(x):
    """Kalman state -> [x1, y1, x2, y2]."""
    area = max(float(x[2, 0]), 1e-6)
    ratio = max(float(x[3, 0]), 1e-6)
    w = np.sqrt(area * ratio)
    h = area / w
    return np.array([x[0, 0] - w / 2.0, x[1, 0] - h / 2.0,
                     x[0, 0] + w / 2.0, x[1, 0] + h / 2.0])


class KalmanBoxTracker:
    """Tracks a single object. State: [cx, cy, area, ratio, vx, vy, v_area]."""

    count = 0

    def __init__(self, bbox, conf=0.0, cls=-1):
        self.F = np.eye(7)
        self.F[0, 4] = self.F[1, 5] = self.F[2, 6] = 1.0
        self.H = np.zeros((4, 7))
        self.H[:4, :4] = np.eye(4)

        self.R = np.eye(4)
        self.R[2:, 2:] *= 10.0
        self.P = np.eye(7)
        self.P[4:, 4:] *= 1000.0   # high uncertainty for unobserved velocities
        self.P *= 10.0
        self.Q = np.eye(7)
        self.Q[-1, -1] *= 0.01
        self.Q[4:, 4:] *= 0.01

        self.x = np.zeros((7, 1))
        self.x[:4] = bbox_to_z(bbox)

        self.id = KalmanBoxTracker.count
        KalmanBoxTracker.count += 1
        self.time_since_update = 0
        self.hits = 0
        self.hit_streak = 0
        self.age = 0
        self.conf = conf
        self.cls = cls

    def update(self, bbox, conf, cls):
        self.time_since_update = 0
        self.hits += 1
        self.hit_streak += 1
        self.conf = conf
        self.cls = cls
        z = bbox_to_z(bbox)
        y = z - self.H @ self.x
        S = self.H @ self.P @ self.H.T + self.R
        K = self.P @ self.H.T @ np.linalg.inv(S)
        self.x = self.x + K @ y
        self.P = (np.eye(7) - K @ self.H) @ self.P

    def predict(self):
        if self.x[6, 0] + self.x[2, 0] <= 0:
            self.x[6, 0] = 0.0
        self.x = self.F @ self.x
        self.P = self.F @ self.P @ self.F.T + self.Q
        self.age += 1
        if self.time_since_update > 0:
            self.hit_streak = 0
        self.time_since_update += 1
        return x_to_bbox(self.x)

    def get_state(self):
        return x_to_bbox(self.x)


def associate(detections, predicted, iou_threshold):
    """Hungarian matching on IoU. Returns (matches, unmatched_dets, unmatched_trks)."""
    if len(predicted) == 0:
        return (np.empty((0, 2), dtype=int),
                np.arange(len(detections)), np.empty((0,), dtype=int))
    if len(detections) == 0:
        return (np.empty((0, 2), dtype=int),
                np.empty((0,), dtype=int), np.arange(len(predicted)))

    iou = iou_batch(detections, predicted)
    rows, cols = linear_sum_assignment(-iou)

    matches = []
    matched_d, matched_t = set(), set()
    for d, t in zip(rows, cols):
        if iou[d, t] >= iou_threshold:
            matches.append([d, t])
            matched_d.add(d)
            matched_t.add(t)

    unmatched_d = np.array([d for d in range(len(detections)) if d not in matched_d], dtype=int)
    unmatched_t = np.array([t for t in range(len(predicted)) if t not in matched_t], dtype=int)
    matches = np.array(matches, dtype=int) if matches else np.empty((0, 2), dtype=int)
    return matches, unmatched_d, unmatched_t


class Sort:
    """
    max_age       frames a track survives without a matching detection
    min_hits      consecutive matches before a track is reported
    iou_threshold minimum IoU for a detection/track match
    """

    def __init__(self, max_age=15, min_hits=3, iou_threshold=0.3):
        self.max_age = max_age
        self.min_hits = min_hits
        self.iou_threshold = iou_threshold
        self.trackers = []
        self.frame_count = 0
        KalmanBoxTracker.count = 0

    def update(self, dets=None):
        """
        dets: (N, 6) array of [x1, y1, x2, y2, conf, cls] (may be empty).
        Returns (M, 7) array of [x1, y1, x2, y2, track_id, cls, conf].
        Call once per frame, even when there are no detections.
        """
        if dets is None or len(dets) == 0:
            dets = np.empty((0, 6))
        dets = np.asarray(dets, dtype=float)
        self.frame_count += 1

        # Predict new locations of existing tracks
        predicted = np.zeros((len(self.trackers), 4))
        dead = []
        for i, trk in enumerate(self.trackers):
            predicted[i] = trk.predict()
            if np.any(np.isnan(predicted[i])):
                dead.append(i)
        predicted = np.delete(predicted, dead, axis=0)
        for i in reversed(dead):
            self.trackers.pop(i)

        matches, unmatched_d, _ = associate(dets[:, :4], predicted, self.iou_threshold)

        for d, t in matches:
            self.trackers[t].update(dets[d, :4], dets[d, 4], int(dets[d, 5]))

        for d in unmatched_d:
            self.trackers.append(KalmanBoxTracker(dets[d, :4], dets[d, 4], int(dets[d, 5])))

        results = []
        for trk in reversed(self.trackers):
            box = trk.get_state()
            if trk.time_since_update < 1 and (
                trk.hit_streak >= self.min_hits or self.frame_count <= self.min_hits
            ):
                results.append(np.concatenate((box, [trk.id, trk.cls, trk.conf])))

        self.trackers = [t for t in self.trackers if t.time_since_update <= self.max_age]
        return np.array(results) if results else np.empty((0, 7))
