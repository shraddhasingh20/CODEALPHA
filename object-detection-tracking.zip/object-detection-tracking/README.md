# Real-Time Object Detection and Tracking (YOLO + SORT)

Detects objects in a webcam stream or video file with a pre-trained **YOLO** model, assigns persistent IDs with a from-scratch **SORT** tracker, and displays bounding boxes, class labels and tracking IDs in real time using **OpenCV**.

## Features

- Webcam or video-file input via OpenCV
- Pre-trained YOLOv8 detector (Ultralytics), weights downloaded automatically
- Self-contained SORT implementation (Kalman filter + Hungarian matching), no extra tracking dependency
- Per-object coloured boxes, `ID <n> <class> <confidence>` labels, and motion trails
- Live FPS and active-track counter
- Optional class filter, annotated-video export, and headless mode

## Project Structure

```
.
├── main.py            # video I/O, detection, tracking, drawing
├── sort.py            # SORT tracker (Kalman filter + IoU association)
├── requirements.txt
├── .gitignore
├── LICENSE
└── README.md
```

## How It Works

1. **Capture**: OpenCV reads frames from the webcam or a video file.
2. **Detect**: YOLO returns boxes, confidence scores and class IDs for each frame.
3. **Track**: SORT predicts where existing tracks should be with a constant-velocity Kalman filter, matches them to new detections by IoU using the Hungarian algorithm, updates matched tracks, starts new ones for unmatched detections, and drops tracks unseen for `--max-age` frames.
4. **Display**: boxes, labels, IDs and trails are drawn on the frame and shown in a window (and optionally saved).

## Installation

Requires Python 3.9+.

```bash
git clone https://github.com/<your-username>/<your-repo>.git
cd <your-repo>

python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate

pip install -r requirements.txt
```

## Usage

```bash
# Webcam (default camera 0)
python main.py

# Video file
python main.py --source path/to/video.mp4

# Save annotated output, no window
python main.py --source path/to/video.mp4 --save output.mp4 --no-display

# Track only people and cars
python main.py --classes person car

# Larger, more accurate model on GPU
python main.py --model yolov8s.pt --device 0
```

Press **q** or **Esc** in the window to quit.

### Options

| Option | Default | Description |
|---|---|---|
| `--source` | `0` | Webcam index or video file path |
| `--model` | `yolov8n.pt` | YOLO weights (`yolov8n/s/m/l/x.pt`) |
| `--conf` | `0.35` | Detection confidence threshold |
| `--nms-iou` | `0.5` | NMS IoU threshold |
| `--imgsz` | `640` | Inference size |
| `--device` | auto | `cpu`, `0`, `mps`, ... |
| `--classes` | all | Class names or IDs to keep |
| `--max-age` | `20` | Frames a lost track is kept alive |
| `--min-hits` | `3` | Matches before a track is displayed |
| `--track-iou` | `0.3` | IoU threshold for association |
| `--trail` | `30` | Motion trail length (`0` disables) |
| `--save` | none | Output video path |
| `--no-display` | off | Run without a window |

## Tuning Tips

- **IDs switching or fragmenting:** raise `--max-age`, lower `--track-iou`, or use a stronger model.
- **Flickering boxes / false tracks:** raise `--conf` or `--min-hits`.
- **Too slow:** use `yolov8n.pt`, lower `--imgsz`, or run on a GPU.

## Limitations

SORT uses only motion and box overlap, so IDs can swap after long occlusions or when objects cross paths. For appearance-based re-identification, swap in Deep SORT (the `Sort.update(dets)` interface in `main.py` is the only place to change).

## Troubleshooting

- **Webcam not opening:** try `--source 1`, and check no other app is using the camera.
- **`cv2.imshow` errors on a server:** use `--no-display --save output.mp4`, or install `opencv-python` (not `opencv-python-headless`).

## Pushing to GitHub

```bash
git init
git add .
git commit -m "Add YOLO + SORT object detection and tracking"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

## Acknowledgements

- [Ultralytics YOLO](https://github.com/ultralytics/ultralytics)
- Bewley et al., *Simple Online and Realtime Tracking* (ICIP 2016)

## License

MIT, see [LICENSE](LICENSE).
