"""
Real-time object detection and tracking.

YOLO (Ultralytics) detects objects in every frame, SORT assigns persistent IDs,
and OpenCV displays boxes, class labels and tracking IDs in real time.

Examples:
    python main.py                          # webcam 0
    python main.py --source video.mp4       # video file
    python main.py --source video.mp4 --save output.mp4 --no-display
    python main.py --classes person car     # track only some classes
"""

import argparse
import sys
import time
from collections import defaultdict, deque

import cv2
import numpy as np
from ultralytics import YOLO

from sort import Sort


def parse_args():
    p = argparse.ArgumentParser(description="Object detection + SORT tracking")
    p.add_argument("--source", default="0",
                   help="webcam index (e.g. 0) or path to a video file (default: 0)")
    p.add_argument("--model", default="yolov8n.pt",
                   help="YOLO weights; downloaded automatically on first run (default: yolov8n.pt)")
    p.add_argument("--conf", type=float, default=0.35, help="detection confidence threshold")
    p.add_argument("--nms-iou", type=float, default=0.5, help="NMS IoU threshold for the detector")
    p.add_argument("--imgsz", type=int, default=640, help="inference image size")
    p.add_argument("--device", default=None, help="'cpu', '0' (first GPU), 'mps', ... (default: auto)")
    p.add_argument("--classes", nargs="*", default=None,
                   help="class names or ids to keep, e.g. --classes person car (default: all)")
    p.add_argument("--max-age", type=int, default=20, help="frames to keep a lost track alive")
    p.add_argument("--min-hits", type=int, default=3, help="matches needed before a track is shown")
    p.add_argument("--track-iou", type=float, default=0.3, help="IoU threshold for track association")
    p.add_argument("--trail", type=int, default=30, help="length of the motion trail (0 to disable)")
    p.add_argument("--save", default=None, help="write annotated video to this path (e.g. output.mp4)")
    p.add_argument("--no-display", action="store_true", help="do not open a window (headless)")
    return p.parse_args()


def resolve_classes(requested, names):
    """Convert class names/ids from the CLI into a list of class ids."""
    if not requested:
        return None
    name_to_id = {v.lower(): k for k, v in names.items()}
    ids = []
    for c in requested:
        if c.isdigit():
            ids.append(int(c))
        elif c.lower() in name_to_id:
            ids.append(name_to_id[c.lower()])
        else:
            sys.exit(f"Unknown class '{c}'. Available: {', '.join(names.values())}")
    return ids


def color_for_id(track_id):
    """Stable, distinct BGR colour for each track ID."""
    rng = np.random.RandomState(int(track_id) * 9973 + 7)
    return tuple(int(v) for v in rng.randint(60, 255, size=3))


def draw_track(frame, box, track_id, label, conf, color):
    x1, y1, x2, y2 = map(int, box)
    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
    text = f"ID {int(track_id)} {label} {conf:.2f}"
    (tw, th), base = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1)
    top = max(y1 - th - base - 4, 0)
    cv2.rectangle(frame, (x1, top), (x1 + tw + 6, top + th + base + 4), color, -1)
    cv2.putText(frame, text, (x1 + 3, top + th + 1), cv2.FONT_HERSHEY_SIMPLEX,
                0.55, (255, 255, 255), 1, cv2.LINE_AA)


def main():
    args = parse_args()

    source = int(args.source) if args.source.isdigit() else args.source
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        sys.exit(f"Could not open video source: {args.source}")

    model = YOLO(args.model)
    class_ids = resolve_classes(args.classes, model.names)
    tracker = Sort(max_age=args.max_age, min_hits=args.min_hits, iou_threshold=args.track_iou)

    fps_in = cap.get(cv2.CAP_PROP_FPS) or 30.0
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    writer = None
    if args.save:
        writer = cv2.VideoWriter(args.save, cv2.VideoWriter_fourcc(*"mp4v"), fps_in, (width, height))

    trails = defaultdict(lambda: deque(maxlen=max(args.trail, 1)))
    prev_time = time.time()
    fps = 0.0

    print("Running. Press 'q' or ESC in the window to quit.")
    while True:
        ok, frame = cap.read()
        if not ok:
            break

        # 1) Detect
        result = model.predict(frame, conf=args.conf, iou=args.nms_iou, imgsz=args.imgsz,
                               classes=class_ids, device=args.device, verbose=False)[0]
        if len(result.boxes):
            dets = np.hstack([
                result.boxes.xyxy.cpu().numpy(),
                result.boxes.conf.cpu().numpy().reshape(-1, 1),
                result.boxes.cls.cpu().numpy().reshape(-1, 1),
            ])
        else:
            dets = np.empty((0, 6))

        # 2) Track
        tracks = tracker.update(dets)

        # 3) Draw
        for x1, y1, x2, y2, tid, cls, conf in tracks:
            color = color_for_id(tid)
            draw_track(frame, (x1, y1, x2, y2), tid, model.names[int(cls)], conf, color)
            if args.trail > 0:
                trails[int(tid)].append((int((x1 + x2) / 2), int(y2)))
                pts = trails[int(tid)]
                for i in range(1, len(pts)):
                    cv2.line(frame, pts[i - 1], pts[i], color, 2)

        now = time.time()
        fps = 0.9 * fps + 0.1 * (1.0 / max(now - prev_time, 1e-6)) if fps else 1.0 / max(now - prev_time, 1e-6)
        prev_time = now
        cv2.putText(frame, f"FPS: {fps:.1f}  Tracks: {len(tracks)}", (10, 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2, cv2.LINE_AA)

        if writer:
            writer.write(frame)
        if not args.no_display:
            cv2.imshow("Object Detection + Tracking", frame)
            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), 27):
                break

    cap.release()
    if writer:
        writer.release()
        print(f"Saved annotated video to {args.save}")
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
